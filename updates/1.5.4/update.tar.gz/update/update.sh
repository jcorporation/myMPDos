#!/bin/sh

export V_MAJOR=3
export V_MINOR=21
export V_POINT=0
export CHECKSUM=aa43adf1fff1d03c7a774d3962557a19d2300698a8e6fb6ce6e088cafbf4c710
alpine-upgrade.sh
