#!/bin/sh
export V_MAJOR=3
export V_MINOR=15
export V_POINT=0
export CHECKSUM=5b1b42973294325fca4581eeda62d30d7a4741c7946234956b32ab98cda7b4fe
alpine-upgrade.sh
