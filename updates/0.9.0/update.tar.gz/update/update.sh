#!/bin/sh
lbu exclude /var/lib/mympd/covercache
