#!/bin/sh

export V_MAJOR=3
export V_MINOR=21
export V_POINT=3
export CHECKSUM=5e5efeb3de14ec05bcdb2785ddf801f4f216de9132db3fbe506b72a642d13f55
alpine-upgrade.sh
