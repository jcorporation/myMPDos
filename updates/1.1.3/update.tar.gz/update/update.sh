#!/bin/sh

export V_MAJOR=3
export V_MINOR=18
export V_POINT=0
export CHECKSUM=d28034e61f15b4a8231e12ce361485d50fb1525ae1e1de25fcc49e92caccd8d0
alpine-upgrade.sh
