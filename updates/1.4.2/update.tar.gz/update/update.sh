#!/bin/sh

export V_MAJOR=3
export V_MINOR=20
export V_POINT=0
export CHECKSUM=b18c3f819e1c3dee06de3d3d0241fe96af204cc386866ae3c31eb146ae2b8628
alpine-upgrade.sh
