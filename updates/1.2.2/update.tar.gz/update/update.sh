#!/bin/sh

rm -f /etc/sysctl.d/disable_ipv6.conf
rm -f /etc/sysctl.d/mympdos.conf
