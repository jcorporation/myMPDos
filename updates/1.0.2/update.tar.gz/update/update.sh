#!/bin/sh

export V_MAJOR=3
export V_MINOR=17
export V_POINT=0
export CHECKSUM=75958328cb8e0ab89e1ad5efc33eff028b7eb09ddf0e95575f85947b02275536
alpine-upgrade.sh

