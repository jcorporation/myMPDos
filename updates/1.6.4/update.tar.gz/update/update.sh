#!/bin/sh

export V_MAJOR=3
export V_MINOR=22
export V_POINT=
export CHECKSUM=213a32b147dfd6522ed8d76784fbfc4947469cf010288d65af32f7024809ca10
alpine-upgrade.sh
