#!/bin/sh

apk update
apk upgrade
apk add ca-certificates
