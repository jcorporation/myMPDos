#!/bin/sh

export V_MAJOR=3
export V_MINOR=15
export V_POINT=4
export CHECKSUM=c19966c40bcea7614a37c9ab5e42393de831e5e26e7b0cea21ac42c39d61d3c6
alpine-upgrade.sh
