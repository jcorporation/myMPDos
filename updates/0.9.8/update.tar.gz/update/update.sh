#!/bin/sh

export V_MAJOR=3
export V_MINOR=16
export V_POINT=0
export CHECKSUM=5639e1492a7e24b2098a9675c50040c13caa4bbf91852e1ef3bdcee43e027aae
alpine-upgrade.sh
