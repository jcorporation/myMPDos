#!/bin/sh

export V_MAJOR=3
export V_MINOR=17
export V_POINT=1
export CHECKSUM=5475fc89462914748348fab607cf84bc39ee7c8e6423e79757fa5299a5f70dd3
alpine-upgrade.sh
