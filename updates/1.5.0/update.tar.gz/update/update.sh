#!/bin/sh

export V_MAJOR=3
export V_MINOR=20
export V_POINT=1
export CHECKSUM=572d498bdbe1146851defe17a763c78c4adbe470c74c666161b120999ea2ee6d
alpine-upgrade.sh
