#!/bin/sh

export V_MAJOR=3
export V_MINOR=20
export V_POINT=3
export CHECKSUM=077ac4604f8a5fc1be6bd3fbc8b0ca8afcec1c79c0a1e528e001677392c2745b
alpine-upgrade.sh
