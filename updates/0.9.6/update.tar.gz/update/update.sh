#!/bin/sh

export V_MAJOR=3
export V_MINOR=15
export V_POINT=3
export CHECKSUM=14b535f2fe854350e0dd7dc0e57218c6b564a5e0b9f488e0d63fe95a9ac5c5d6
alpine-upgrade.sh
