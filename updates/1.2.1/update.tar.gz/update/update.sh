#!/bin/sh

# replace mpc with mympdos fork
apk remove mpc
apd add mympdos-mpc
