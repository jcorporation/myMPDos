#!/bin/sh

# replace mpc with mympdos fork
apk del mpc
apk add mympdos-mpc
