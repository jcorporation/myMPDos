#!/bin/sh

export V_MAJOR=3
export V_MINOR=18
export V_POINT=4
export CHECKSUM=ec0c111a465b2fcf8190b45d5b8c41cf9c8b9160f9eb3153590076f8ca1a9942
alpine-upgrade.sh
