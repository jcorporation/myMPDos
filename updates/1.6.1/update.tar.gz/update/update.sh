#!/bin/sh

export V_MAJOR=3
export V_MINOR=21
export V_POINT=2
export CHECKSUM=090be50ac6682d8472e2821519c06ce0aa248e0b4768c5e53388f93f1125396a
alpine-upgrade.sh
