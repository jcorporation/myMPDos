#!/bin/sh
export V_MAJOR=3
export V_MINOR=14
export V_POINT=2
export CHECKSUM=0824cadf015a45d24ff9429da4cb1b5b20a091606601e59dc8575b9aa6e9d81a
alpine-upgrade.sh
