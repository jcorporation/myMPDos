#!/bin/sh

export V_MAJOR=3
export V_MINOR=18
export V_POINT=2
export CHECKSUM=16afb0361414bf3c0a326fc03ee77fe56ce3f63174a204922b196c81d56e945c
alpine-upgrade.sh
