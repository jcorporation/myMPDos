#!/bin/sh

export V_MAJOR=3
export V_MINOR=17
export V_POINT=3
export CHECKSUM=2ca8cb1259f6c43b13e7f2a1dd1662779440ac4471405a5e285e75e26f19e5e8
alpine-upgrade.sh
