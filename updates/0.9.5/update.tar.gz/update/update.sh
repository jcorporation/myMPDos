#!/bin/sh

export V_MAJOR=3
export V_MINOR=15
export V_POINT=2
export CHECKSUM=685da914bd39bec75101b9d130cc0c1cb8e33f609a53e66b3fa2e7e78861ed21
alpine-upgrade.sh
