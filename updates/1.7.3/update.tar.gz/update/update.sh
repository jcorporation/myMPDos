#!/bin/sh

export V_MAJOR=3
export V_MINOR=22
export V_POINT=2
export CHECKSUM=a82b006fb6e13523d2593b8fe4c0e31d7045328d580ec9f9ed09fc6fe1329c94
alpine-upgrade.sh
