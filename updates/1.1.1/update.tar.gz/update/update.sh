#!/bin/sh

export V_MAJOR=3
export V_MINOR=17
export V_POINT=2
export CHECKSUM=0cb8df694f26be91d3313023c79eb7bd5687c9b0e5a5975dc11dd6e42066dd4e
alpine-upgrade.sh
