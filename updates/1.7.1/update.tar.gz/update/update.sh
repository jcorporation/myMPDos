#!/bin/sh

export V_MAJOR=3
export V_MINOR=22
export V_POINT=1
export CHECKSUM=182cad98919bc2838799d20e1644c1e7a4cc66125a408261bb504d2e878c629f
alpine-upgrade.sh
