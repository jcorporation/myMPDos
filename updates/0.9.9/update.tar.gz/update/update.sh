#!/bin/sh

export V_MAJOR=3
export V_MINOR=16
export V_POINT=1
export CHECKSUM=f182857f89f05d0420f4b5c2df32a73e06c8559d0286bb912d04b99a458db536
alpine-upgrade.sh
