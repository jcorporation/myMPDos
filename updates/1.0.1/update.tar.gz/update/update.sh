#!/bin/sh

export V_MAJOR=3
export V_MINOR=16
export V_POINT=3
export CHECKSUM=7de019765f238588ef55fad7423744c4522948b1b4d9dd484de1d4f46a127936
alpine-upgrade.sh
