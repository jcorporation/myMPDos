#!/bin/sh

apk update
apk upgrade
