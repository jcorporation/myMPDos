#!/bin/sh
export V_MAJOR=3
export V_MINOR=14
export V_POINT=3
export CHECKSUM=aa7796b4108a776a9df65c2508d90a1036bbf217292d57297b49513dc59c60f2
alpine-upgrade.sh
