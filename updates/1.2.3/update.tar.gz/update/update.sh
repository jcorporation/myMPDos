#!/bin/sh

export V_MAJOR=3
export V_MINOR=18
export V_POINT=3
export CHECKSUM=dcc31a58f67eaee0cce24d4141a2f63a911c7baa0939dfc123218fd2f1bb9d4b
alpine-upgrade.sh
