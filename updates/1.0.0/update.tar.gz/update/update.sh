#!/bin/sh

export V_MAJOR=3
export V_MINOR=16
export V_POINT=2
export CHECKSUM=accb13b1606d40aec1e542ed8993e7a615be16125e8764ca1e51fa18e3c1bc7b
alpine-upgrade.sh

