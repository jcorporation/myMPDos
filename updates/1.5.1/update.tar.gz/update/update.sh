#!/bin/sh

export V_MAJOR=3
export V_MINOR=20
export V_POINT=2
export CHECKSUM=252e969760f53de420777ba7297c2f81cfb726ce6e5d48066d19cf2215ea0e88
alpine-upgrade.sh
